﻿using Microsoft.AspNetCore.Mvc;
using Services.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace lab3.Controllers
{
    public class UsersController : Controller
    {
        IUsersService _usersService;
        UsersController(IUsersService usersService)
        {
            this._usersService = usersService;
        }
        public PaginatedData<UserDto> Get(PaginationDto dto)
        {
            return this._usersService.Get(dto);
        }
        public UserDto Post(PostUserDto dto)
        {
            return this._usersService.Post(dto);
        }
        public IActionResult Index()
        {
            return View();
        }
    }
}
