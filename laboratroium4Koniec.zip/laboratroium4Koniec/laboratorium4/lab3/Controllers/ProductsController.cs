﻿using Microsoft.AspNetCore.Mvc;
using Services.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace lab3.Controllers
{
    public class ProductsController : Controller
    {
        IProductsService _productsService;
        ProductsController(IProductsService productsService)
        {
            this._productsService = productsService;
        }
        [HttpGet]
        public PaginatedData<ProductDto> Get(ProductDto dto)
        {
            return this._productsService.Get(dto);
        }
        [HttpPut]
        public ProductDto Put(int productId, PostProductDto dto)
        {
            return this._productsService.Put(productId,dto);
        }
        [HttpPost]
        public ProductDto Post(PostProductDto dto)
        {
            return this._productsService.Post(dto);
        }
        [HttpDelete]
        public bool Delete(int productId)
        {
            return this._productsService.Delete(productId);
        }
        public IActionResult Index()
        {
            return View();
        }
    }
}
