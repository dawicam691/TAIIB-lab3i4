﻿using Microsoft.AspNetCore.Mvc;
using Models;
using Services.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace lab3.Controllers
{
    public class BasketController : Controller
    {
        IBasketService _basketService;
        BasketController(IBasketService basketService)
        {
            this._basketService = basketService;
        }
        [HttpGet]
        public IEnumerable<BasketItem> Get()
        {
            return this._basketService.Get();
        }
        [HttpPost]
        public IEnumerable<BasketItem> Post(int productId, double count)
        {
            return this._basketService.Post(productId, count);
        }
        [HttpPut]
        public IEnumerable<BasketItem> Put(int basketItemId, double count)
        {
            return this._basketService.Put(basketItemId, count);
        }
        [HttpDelete]
        public IEnumerable<BasketItem> Delete(int basketItemId)
        {
            return this._basketService.Delete(basketItemId);
        }
        [HttpDelete]
        public bool Clear()
        {
            return this._basketService.Clear();
        }
        public IActionResult Index()
        {
            return View();
        }
    }
}
