﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models;
using services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace lab3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private IProductService _productService;

        public ProductController(IProductService productService)
        {
            this._productService = productService;
        }
        [HttpGet]
        public List<Product> Get()
        {
            return _productService.Get();
        }
    }
}
