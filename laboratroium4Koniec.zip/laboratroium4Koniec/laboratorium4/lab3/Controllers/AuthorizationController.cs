﻿using Microsoft.AspNetCore.Mvc;
using Services.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace lab3.Controllers
{
    public class AuthorizationController : Controller
    {
        private IAuthorizationService _authorizationService;
        AuthorizationController(IAuthorizationService authorizationService)
        {
            this._authorizationService = authorizationService;
        }
        [HttpGet]
        public int Login(AuthorizationDto dto)
        {
            return _authorizationService.Login(dto);
        }
        public IActionResult Index()
        {
            return View();
        }
    }
}
