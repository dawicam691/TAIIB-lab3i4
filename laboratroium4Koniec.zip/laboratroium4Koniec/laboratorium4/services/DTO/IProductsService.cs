﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.DTO
{
    public interface IProductsService
    {
        public PaginatedData<ProductDto> Get(ProductDto dto);
        public ProductDto Put(int productId, PostProductDto dto);
        public ProductDto Post(PostProductDto dto);
        public bool Delete(int productId);

    }
}
