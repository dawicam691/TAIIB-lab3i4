﻿using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Services.DTO
{
    public class ProductsService : IProductsService
    {
        private readonly Database _database;
        public ProductsService(Database database)
        {
            this._database = database;
        }
        public bool Delete(int productId)
        {
            _database.Products.Remove(new Product { Id= productId });
            Product product = _database.Products.Find(new Product { Id = productId });
            if (product == null)
                return true;
            return false;
        }

        public PaginatedData<ProductDto> Get(ProductDto dto)
        {
            PaginatedData<Product> paginatedData=new PaginatedData<Product>();
            List<Product> produkty = _database.Products.ToList();
            paginatedData.Count = produkty.Count();
            produkty.Sort();
            paginatedData.Data = produkty;
            PaginatedData<ProductDto> paginatedDataNowe = new PaginatedData<ProductDto> { Count = paginatedData.Count, Data = paginatedData.Data };
            _database.SaveChanges();
            return paginatedDataNowe;
        }

        public ProductDto Post(PostProductDto dto)
        {
            Product product = new Product();
            product.Name = dto.Name;
            product.Price = dto.Price;
            product.Description = dto.Description;
            _database.Products.Add(product);
            _database.SaveChanges();
            return new ProductDto {
                Id=product.Id, 
                Description=product.Description, 
                Name=product.Name, 
                Price=product.Price 
            };
        }

        public ProductDto Put(int productId, PostProductDto dto)
        {
            Product product = (Product)(from p in _database.Products
                                   where p.Id == productId
                                   select p);
            if(product != null)
            {
                product.Id = productId;
                product.Name = dto.Name;
                product.Price = dto.Price;
                product.Description = dto.Description;
            }
            _database.SaveChanges();
            return new ProductDto
            {
                Id = product.Id,
                Description = product.Description,
                Name = product.Name,
                Price = product.Price
            };
        }
    }
}
